/*
 * Theme Name: Uthan
 * Author: template_path
 * Author URI: https://themeforest.net/user/template_path
 * Theme URI: http://z.commonsupport.com/uthan/
 * Description: Uthan is a Butcher & Meat Shop WordPress Theme.
 * Version: 1.0.0
 * License: This theme or plugin is comprised of two parts. (1) the PHP code and integrated HTML are licensed under the General Public License (GPL). You will find a copy of the GPL in the same directory as this text file. (2) All other parts, but not limited to the CSS code, images, and design are licensed according to the license purchased from Envato.  Read more about licensing here: http://themeforest.net/licenses
 * License URI: license.txt
 * Tags: blog, two-columns, left-sidebar, accessibility-ready, custom-background, custom-colors, custom-header, custom-logo, custom-menu, editor-style, featured-images, microformats, post-formats, rtl-language-support, sticky-post, threaded-comments, translation-ready
 * Text Domain: uthan
 * Tested up to: 6.0.2
 * Requires PHP: 7.0
*/