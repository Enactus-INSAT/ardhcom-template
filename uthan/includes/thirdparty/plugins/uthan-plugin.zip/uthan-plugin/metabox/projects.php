<?php
return array(
	'title'      => 'Uthan Project Setting',
	'id'         => 'uthan_meta_projects',
	'icon'       => 'el el-cogs',
	'position'   => 'normal',
	'priority'   => 'core',
	'post_types' => array( 'uthan_project' ),
	'sections'   => array(
		array(
			'id'     => 'uthan_projects_meta_setting',
			'fields' => array(
				array(
					'id'    => 'subtitle',
					'type'  => 'text',
					'title' => esc_html__( 'Subtitle', 'uthan' ),
				),
				array(
					'id'    => 'page_link',
					'type'  => 'text',
					'title' => esc_html__( 'Page Link', 'uthan' ),
				),
				array(
					'id'    => 'image_link',
					'type'  => 'text',
					'title' => esc_html__( 'Image Link', 'uthan' ),
				),
				array(
					'id'    => 'meta_number',
					'type'  => 'text',
					'title' => esc_html__( 'Column Number', 'uthan' ),
					'default' => esc_html__( '3', 'uthan' ),
				),
			),
		),
	),
);