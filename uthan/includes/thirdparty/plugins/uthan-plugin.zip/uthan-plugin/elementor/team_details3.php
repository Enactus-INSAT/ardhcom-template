<?php

namespace UTHANPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Plugin;

/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Team_Details3 extends Widget_Base {

	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'uthan_team_details3';
	}

	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Team Details 3', 'uthan' );
	}

	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fa fa-briefcase';
	}

	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'uthan' ];
	}
	
	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'team_details3',
			[
				'label' => esc_html__( 'Team Details 3', 'uthan' ),
			]
		);
		$this->add_control(
			'sec_class',
			[
				'label'       => __( 'Section Class', 'rashid' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter Section Class', 'rashid' ),
			]
		);
		

		$this->end_controls_section();
		
		// New Tab#1

		$this->start_controls_section(
					'content_section',
					[
						'label' => __( 'Skill Block', 'rashid' ),
						'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
					]
				);
				$this->add_control(
					'title',
					[
						'label'       => __( 'Title', 'rashid' ),
						'type'        => Controls_Manager::TEXTAREA,
						'dynamic'     => [
							'active' => true,
						],
						'placeholder' => __( 'Enter your title', 'rashid' ),
					]
				);
				$this->add_control(
				  'repeat', 
					[
						'type' => Controls_Manager::REPEATER,
						'seperator' => 'before',
						'default' => 
							[
								['block_title' => esc_html__('Projects Completed', 'rashid')],
							],
						'fields' => 
							[
								'block_title' => 
								[
									'name' => 'block_title',
									'label' => esc_html__('Title', 'rashid'),
									'type' => Controls_Manager::TEXTAREA,
									'default' => esc_html__('', 'rashid')
								],
								'ff_stop' => 
								[
									'name' => 'ff_stop',
									'label' => esc_html__('Counter Stop', 'rashid'),
									'type' => Controls_Manager::TEXT,
									'default' => esc_html__('', 'hekim')
								],
								'ff_sing' => 
								[
									'name' => 'ff_sing',
									'label' => esc_html__('Counter Sing', 'rashid'),
									'type' => Controls_Manager::TEXT,
									'default' => esc_html__('', 'hekim')
								],
							],
						'title_field' => '{{block_title}}',
					 ]
			);
				
				
		$this->end_controls_section();	
		
		// New Tab#2

		$this->start_controls_section(
					'content_section2',
					[
						'label' => __( 'Contact Block', 'rashid' ),
						'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
					]
				);
				$this->add_control(
					'title2',
					[
						'label'       => __( 'Title', 'rashid' ),
						'type'        => Controls_Manager::TEXTAREA,
						'dynamic'     => [
							'active' => true,
						],
						'placeholder' => __( 'Enter your title', 'rashid' ),
					]
				);
				$this->add_control(
					'contact_us_form',
					[
						'label'       => __( 'Contact Form 7 Url', 'rashid' ),
						'type'        => Controls_Manager::TEXTAREA,
						'dynamic'     => [
							'active' => true,
						],
						'placeholder' => __( 'Enter your Contact Form 7 Url', 'rashid' ),
						'default'     => __( '', 'rashid' ),
					]
				);
				
				
		$this->end_controls_section();	

		// Progress Box Title 	==================			
		$this->start_controls_section(
			'progress_title_settings',
			array(
				'label' => __( 'Progress Title Setting', 'ecolab' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);
				
		$this->add_control(
			'show_title1',
			array(
				'label' => esc_html__( 'Show Title 1', 'ecolabe' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'show' => [
						'show' => esc_html__( 'Show', 'ecolab' ),	
						'icon' => 'eicon-check-circle',
					],
					'none' => [
						'none' => esc_html__( 'Hide', 'ecolab' ),
						'icon' => 'eicon-close-circle',
					],
				],
				'default' => 'show',
				'selectors' => array(
					'{{WRAPPER}} .team-details .content-box .skills-box h3' => 'display: {{VALUE}} !important',
				),
			)
		);
		
		$this->add_control(
			'title1_alingment',
			array(
				'label' => esc_html__( 'Alignment', 'ecolab' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'ecolab' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'ecolab' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'ecolab' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'center',
				'condition'    => array( 'show_title1' => 'show' ),
				'toggle' => true,
				'selectors' => array(				
					'{{WRAPPER}} .team-details .content-box .skills-box h3' => 'text-align: {{VALUE}} !important',
				),
			)
		);
		
		$this->add_control(
			'title1_margin',
			array(
				'label'     => __( 'Margin', 'ecolab' ),
				'condition'    => array( 'show_title1' => 'show' ),
				'type'      => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' =>  ['px', '%', 'em' ],
			
				'selectors' => array(
					'{{WRAPPER}} .team-details .content-box .skills-box h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
				),
			)
		);

		$this->add_control(
			'title1_padding',
			array(
				'label'     => __( 'Padding', 'ecolab' ),
				'condition'    => array( 'show_title1' => 'show' ),
				'type'      => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' =>  ['px', '%', 'em' ],			
				'selectors' => array(
					'{{WRAPPER}} .team-details .content-box .skills-box h3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
				),
			)
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'title1_typography',
				'condition'    => array( 'show_title1' => 'show' ),
				'label'    => __( 'Typography', 'ecolab' ),
				'selector' => '{{WRAPPER}} .team-details .content-box .skills-box h3',
			)
		);
		
		$this->add_control(
			'title1_color',
			array(
				'label'     => __( 'Color', 'ecolab' ),
				'condition'    => array( 'show_title1' => 'show' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .team-details .content-box .skills-box h3' => 'color: {{VALUE}} !important',		
				),
			)
		);

		$this->end_controls_section();					
		//End of Progress Title 	==================
		
		// Progress Box =======================
		$this->start_controls_section(
			'progress_box_settings',
			array(
				'label' => __( 'Progress Box Setting', 'ecolab' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);
		
		$this->add_control(
			'show_progress_box',
			array(
				'label' => esc_html__( 'Show Progress Box', 'ecolab' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'show' => [
						'show' => esc_html__( 'Show', 'ecolab' ),	
						'icon' => 'eicon-check-circle',
					],
					'none' => [
						'none' => esc_html__( 'Hide', 'ecolab' ),
						'icon' => 'eicon-close-circle',
					],
				],
				'default' => 'show',
				'selectors' => array(
					'{{WRAPPER}} .team-details .content-box .skills-box .progress-box' => 'display: {{VALUE}} !important',
				),
			)
		);
		
		$this->add_control(
			'progress_title_alingment',
			array(
				'label' => esc_html__( 'Alignment', 'ecolab' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'ecolab' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'ecolab' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'ecolab' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'center',
				'condition'    => array( 'show_progress_box' => 'show' ),
				'toggle' => true,
				'selectors' => array(
					'{{WRAPPER}} .team-details .content-box .skills-box .progress-box p' => 'text-align: {{VALUE}} !important',
				),
			)
		);
		
		$this->add_control(
			'progress_title_margin',
			array(
				'label'     => __( 'Margin', 'ecolab' ),
				'type'      => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' =>  ['px', '%', 'em' ],
				'condition'    => array( 'show_progress_box' => 'show' ),
				'selectors' => array(
					'{{WRAPPER}} .team-details .content-box .skills-box .progress-box p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
				),
			)
		);
		
		$this->add_control(
			'progress_title_padding',
			array(
				'label'     => __( 'Padding', 'ecolab' ),
				'type'      => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' =>  ['px', '%', 'em' ],
				'condition'    => array( 'show_progress_box' => 'show' ),
				'selectors' => array(
					'{{WRAPPER}} .team-details .content-box .skills-box .progress-box p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
				),
			)
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'progress_title_typography',
				'condition'    => array( 'show_progress_box' => 'show' ),
				'label'    => __( 'Typography', 'ecolab' ),
				'selector' => '{{WRAPPER}} .team-details .content-box .skills-box .progress-box p',
			)
		);
		
		$this->add_control(
			'progress_title_color',
			array(
				'label'     => __( 'Color', 'ecolab' ),
				'condition'    => array( 'show_progress_box' => 'show' ),
				'separator' => 'after',
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .team-details .content-box .skills-box .progress-box p' => 'color: {{VALUE}} !important',
				),
			)
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'count_text_typography',
				'condition'    => array( 'show_progress_box' => 'show' ),
				'label'    => __( 'Typography', 'ecolab' ),
				'selector' => '{{WRAPPER}} .team-details .content-box .skills-box .progress-box .count-text',
			)
		);
		
		$this->add_control(
			'count_text_color',
			array(
				'label'     => __( 'Count Text Color', 'ecolab' ),
				'condition'    => array( 'show_progress_box' => 'show' ),
				'separator' => 'after',
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .team-details .content-box .skills-box .progress-box .count-text' => 'color: {{VALUE}} !important',
				),
			)
		);
		
		$this->add_control(
			'progress_bar_color',
			array(
				'label'     => __( 'Progress Bar Color', 'ecolab' ),
				'condition'    => array( 'show_progress_box' => 'show' ),
				'separator' => 'after',
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .team-details .content-box .progress-box .bar' => 'background: {{VALUE}} !important',
				),
			)
		);
		
		$this->add_control(
			'progress_count_bar_color',
			array(
				'label'     => __( 'Progress Count Bar Color', 'ecolab' ),
				'condition'    => array( 'show_progress_box' => 'show' ),
				'separator' => 'after',
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .team-details .content-box .progress-box .bar-inner' => 'background: {{VALUE}} !important',
				),
			)
		);

		$this->end_controls_section();
		//End of Progress Box =========			
		
		// Inner Form Title ==================			
		$this->start_controls_section(
			'form_title_settings',
			array(
				'label' => __( 'Form Title Setting', 'ecolab' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);
				
		$this->add_control(
			'show_title2',
			array(
				'label' => esc_html__( 'Show Title 2', 'ecolabe' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'show' => [
						'show' => esc_html__( 'Show', 'ecolab' ),	
						'icon' => 'eicon-check-circle',
					],
					'none' => [
						'none' => esc_html__( 'Hide', 'ecolab' ),
						'icon' => 'eicon-close-circle',
					],
				],
				'default' => 'show',
				'selectors' => array(
					'{{WRAPPER}} .team-details .content-box .form-inner h3' => 'display: {{VALUE}} !important',
				),
			)
		);
		
		$this->add_control(
			'title2_alingment',
			array(
				'label' => esc_html__( 'Alignment', 'ecolab' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'ecolab' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'ecolab' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'ecolab' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'center',
				'condition'    => array( 'show_title2' => 'show' ),
				'toggle' => true,
				'selectors' => array(				
					'{{WRAPPER}} .team-details .content-box .form-inner h3' => 'text-align: {{VALUE}} !important',
				),
			)
		);
		
		$this->add_control(
			'title2_margin',
			array(
				'label'     => __( 'Margin', 'ecolab' ),
				'condition'    => array( 'show_title2' => 'show' ),
				'type'      => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' =>  ['px', '%', 'em' ],			
				'selectors' => array(
					'{{WRAPPER}} .team-details .content-box .form-inner h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
				),
			)
		);

		$this->add_control(
			'title2_padding',
			array(
				'label'     => __( 'Padding', 'ecolab' ),
				'condition'    => array( 'show_title2' => 'show' ),
				'type'      => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' =>  ['px', '%', 'em' ],			
				'selectors' => array(
					'{{WRAPPER}} .team-details .content-box .form-inner h3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
				),
			)
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'title2_typography',
				'condition'    => array( 'show_title2' => 'show' ),
				'label'    => __( 'Typography', 'ecolab' ),
				'selector' => '{{WRAPPER}} .team-details .content-box .form-inner h3',
			)
		);
		
		$this->add_control(
			'title2_color',
			array(
				'label'     => __( 'Color', 'ecolab' ),
				'condition'    => array( 'show_title2' => 'show' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .team-details .content-box .form-inner h3' => 'color: {{VALUE}} !important',		
				),
			)
		);

		$this->end_controls_section();					
		//End of  Title 	==================
		
		// Form ==== 
		$this->start_controls_section(
			'input_control',
			array(
				'label' => __( 'Input Settings', 'ecolab' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);
		
		$this->add_control(
			'show_form',
			array(
				'label' => esc_html__( 'Show Form', 'ecolab' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'show' => [
						'show' => esc_html__( 'Show', 'ecolab' ),	
						'icon' => 'eicon-check-circle',
					],
					'none' => [
						'none' => esc_html__( 'Hide', 'ecolab' ),
						'icon' => 'eicon-close-circle',
					],
				],
				'default' => 'show',
				'selectors' => array(
					'{{WRAPPER}} .form-inner .form-group input' => 'display: {{VALUE}} !important',
					'{{WRAPPER}} .form-inner .form-group textarea' => 'display: {{VALUE}} !important',
				),
			)
		);
		
		$this->add_control(
			'placeholder_color',
			array(
				'label'     => __( 'Placeholder Color', 'ecolab' ),
				'condition'    => array( 'show_form' => 'show' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .form-inner .form-group input::placeholder' => 'color: {{VALUE}} !important',
					'{{WRAPPER}} .form-inner .form-group textarea::placeholder' => 'color: {{VALUE}} !important',
				),
			)
		);
		
		$this->add_control(
			'input_color',
			array(
				'label'     => __( 'Input Color', 'ecolab' ),
				'condition'    => array( 'show_form' => 'show' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .form-inner .form-group input' => 'color: {{VALUE}} !important',
					'{{WRAPPER}} .form-inner .form-group textarea' => 'color: {{VALUE}} !important',
				),
			)
		);
		
		$this->add_control(
			'input_bg_color',
			array(
				'label'     => __( 'Background Color', 'ecolab' ),
				'condition'    => array( 'show_form' => 'show' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .form-inner .form-group input' => 'background: {{VALUE}} !important',
					'{{WRAPPER}} .form-inner .form-group textarea' => 'background: {{VALUE}} !important',
				),
			)
		);	
			
		$this->add_control(
			'input_padding',
			array(
				'label'     => __( 'Padding', 'ecolab' ),
				'type'      => \Elementor\Controls_Manager::DIMENSIONS,
				'condition'    => array( 'show_form' => 'show' ),
				'size_units' =>  ['px', '%', 'em' ],			
				'selectors' => array(
					'{{WRAPPER}} .form-inner .form-group input' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
					'{{WRAPPER}} .form-inner .form-group textarea' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
				),
			)
		);

		$this->add_control(
			'input_margin',
			array(
				'label'     => __( 'Margin', 'ecolab' ),
				'type'      => \Elementor\Controls_Manager::DIMENSIONS,
				'condition'    => array( 'show_form' => 'show' ),
				'size_units' =>  ['px', '%', 'em' ],
				'selectors' => array(
					'{{WRAPPER}} .form-inner .form-group input' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
					'{{WRAPPER}} .form-inner .form-group textarea' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'input_typography',
				'condition'    => array( 'show_form' => 'show' ),
				'label'    => __( 'Typography', 'ecolab' ),
				'selector' => '{{WRAPPER}} .form-inner .form-group input, .default-form .form-group textarea',
			)
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			array(
				'name' => 'Input Border',
				'condition'    => array( 'show_form' => 'show' ),
				'selector' => '{{WRAPPER}} .form-inner .form-group input, .default-form .form-group textarea',
			)
		);

		$this->end_controls_section();		
		//End of Form	
		
		//========== Button with Background ===================================
		$this->start_controls_section(
			'button_control',
			array(
				'label' => __( 'Contact Button Settings', 'ecolab' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);
		
		$this->add_control(
			'show_button',
			array(
				'label' => esc_html__( 'Show Button', 'ecolab' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'show' => [
						'show' => esc_html__( 'Show', 'ecolab' ),	
						'icon' => 'eicon-check-circle',
					],
					'none' => [
						'none' => esc_html__( 'Hide', 'ecolab' ),
						'icon' => 'eicon-close-circle',
					],
				],
				'default' => 'show',
				'selectors' => array(
					'{{WRAPPER}} .form-inner .form-group button' => 'display: {{VALUE}} !important',
				),
			)
		);		
		
		$this->add_control(
			'button_color',
			array(
				'label'     => __( 'Button Color', 'ecolab' ),
				'condition'    => array( 'show_button' => 'show' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .form-inner .form-group button' => 'color: {{VALUE}} !important',
				),
			)
		);
		$this->add_control(
			'button_bg_color',
			array(
				'label'     => __( 'Background Color', 'ecolab' ),
				'condition'    => array( 'show_button' => 'show' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .form-inner .form-group button' => 'background: {{VALUE}} !important',
				),
			)
		);
		$this->add_control(
			'button_hover_color',
			array(
				'label'     => __( 'Button Hover Color', 'ecolab' ),
				'condition'    => array( 'show_button' => 'show' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .form-inner .form-group button:hover' => 'color: {{VALUE}} !important',
				),
			)
		);
			
		$this->add_control(
			'button_hover_bg_color',
			array(
				'label'     => __( 'Hover Background Color', 'ecolab' ),
				'condition'    => array( 'show_button' => 'show' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .form-inner .form-group button:before' => 'background: {{VALUE}} !important',
				),
			)
		);				
		$this->add_control(
			'button_padding',
			array(
				'label'     => __( 'Padding', 'ecolab' ),
				'type'      => \Elementor\Controls_Manager::DIMENSIONS,
				'condition'    => array( 'show_button' => 'show' ),
				'size_units' =>  ['px', '%', 'em' ],
			
				'selectors' => array(
					'{{WRAPPER}} .form-inner .form-group button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
				),
			)
		);

		$this->add_control(
			'button_margin',
			array(
				'label'     => __( 'Margin', 'ecolab' ),
				'type'      => \Elementor\Controls_Manager::DIMENSIONS,
				'condition'    => array( 'show_button' => 'show' ),
				'size_units' =>  ['px', '%', 'em' ],
				'selectors' => array(
					'{{WRAPPER}} .form-inner .form-group button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'button_typography',
				'condition'    => array( 'show_button' => 'show' ),
				'label'    => __( 'Typography', 'ecolab' ),
				'selector' => '{{WRAPPER}} .form-inner .form-group button',
			)
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			array(
				'name' => 'border',
				'condition'    => array( 'show_button' => 'show' ),
				'selector' => '{{WRAPPER}} .form-inner .form-group button',
			)
		);
		
		$this->add_control(
			'border_radius',
			array(
				'label'     => __( 'Border Radius', 'ecolab' ),
				'type'      => \Elementor\Controls_Manager::DIMENSIONS,
				'condition'    => array( 'show_box' => 'show' ),
				'size_units' =>  ['px', '%', 'em' ],
			
				'selectors' => array(
					'{{WRAPPER}} .form-inner .form-group button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
					'{{WRAPPER}} .form-inner .form-group button:before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
				),
			)
		);

		$this->end_controls_section();		
		//End of Form Button
		
		
	}

	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
		?>

		<section class="team-details p_relative pb_150 <?php echo esc_attr($settings['sec_class']);?>">
			<div class="auto-container">
				<div class="row clearfix">
					<div class="col-lg-12 col-md-12 col-sm-12 content-column">
						<div class="content-box p_relative d_block ml_20">
							<div class="skills-box p_relative d_block mb_65">
								<h3 class="fs_22 lh_30 fw_medium mb_6"><?php echo $settings['title'];?></h3>
								<div class="progress-inner">
								
									<?php foreach($settings['repeat'] as $item):?>
								
									<div class="progress-box p_relative d_block mb_15">
										<div class="bar-box">
											<p class="d_block fs_15 lh_26 mb_3"><?php echo wp_kses($item['block_title'], $allowed_tags);?></p>
											<div class="bar p_relative">
												<div class="bar-inner count-bar p_relative d_block" data-percent="<?php echo esc_attr($item['ff_stop']);?><?php echo esc_attr($item['ff_sing']);?>">
													<div class="count-text p_absolute fs_16 lh_26 fw_medium theme_color"><?php echo esc_attr($item['ff_stop']);?><?php echo esc_attr($item['ff_sing']);?></div>
												</div>
											</div>
										</div>
									</div>
									
									<?php endforeach; ?>
									
								</div>
							</div>
							<div class="form-inner">
								<h3 class="fs_22 lh_30 fw_medium mb_35"><?php echo $settings['title2'];?></h3>
								<?php echo do_shortcode( $settings['contact_us_form'] );?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
            
		<?php 
	}

}
