<?php

namespace UTHANPLUGIN\Element;


class Elementor {
	static $widgets = array(
		'slider',
		'title',
		'about_left',
		'about_right',
		'chooseus',
		'service',
		'funfact',
		'team',
		'portfolios',
		'testimonial',
		'pricing',
		'cta',
		'blog',
		'footer',
		'feature',
		'process',
		'gallery',
		'pricing_tab',
		'history',
		'team_details1',
		'team_details2',
		'team_details3',
		'faq_left',
		'faq_right',
		'contact',
		'career_left',
		'career_right',
		'project_details1',
		'project_details2',
		'project_details3',
		'project_details4',
		'wi_catagory',
		'wi_download',
		'service_details1',
		'service_details2',
		'service_details3',
		'contact_info',
		'footer_widget1',
		'footer_widget2',
		'footer_widget3',
		'footer_widget4',
		'footer_widget5',
		'footer_widget6',
        'team_block',
	);

	static function init() {
		add_action( 'elementor/init', array( __CLASS__, 'loader' ) );
		add_action( 'elementor/elements/categories_registered', array( __CLASS__, 'register_cats' ) );
	}

	static function loader() {

		foreach ( self::$widgets as $widget ) {

			$file = UTHANPLUGIN_PLUGIN_PATH . '/elementor/' . $widget . '.php';
			if ( file_exists( $file ) ) {
				require_once $file;
			}

			add_action( 'elementor/widgets/widgets_registered', array( __CLASS__, 'register' ) );
		}
	}

	static function register( $elemntor ) {
		foreach ( self::$widgets as $widget ) {
			$class = '\\UTHANPLUGIN\\Element\\' . ucwords( $widget );

			if ( class_exists( $class ) ) {
				$elemntor->register_widget_type( new $class );
			}
		}
	}

	static function register_cats( $elements_manager ) {

		$elements_manager->add_category(
			'uthan',
			[
				'title' => esc_html__( 'Uthan', 'uthan' ),
				'icon'  => 'fa fa-plug',
			]
		);
		$elements_manager->add_category(
			'csslatepath',
			[
				'title' => esc_html__( 'Template Path', 'uthan' ),
				'icon'  => 'fa fa-plug',
			]
		);

	}
}

Elementor::init();