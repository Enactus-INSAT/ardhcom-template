<?php

namespace UTHANPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Plugin;



/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Slider extends Widget_Base {

	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'uthan_slider';
	}

	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Slider', 'uthan' );
	}

	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fa fa-briefcase';
	}

	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'uthan' ];
	}
	
	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'slider',
			[
				'label' => esc_html__( 'Slider', 'uthan' ),
			]
		);
	
		$this->add_control(
            'style', 
				[
					'label'   => esc_html__( 'Choose Different Style', 'uthan' ),
					'label_block' => true,
					'type'    => Controls_Manager::SELECT,
					'return_value' => 'style1',
                    'default'      => 'style1',
					'options' => array(
						'style1' => esc_html__( 'Choose Style One', 'uthan' ),
						'style2' => esc_html__( 'Choose Style Two', 'uthan' ),
						'style3' => esc_html__( 'Choose Style Three', 'uthan' ),
					),
				]
		);
		$this->add_control(
			'bgimg',
			[
				'label' => esc_html__('Background image', 'rashid'),
				'conditions' => array(
					'relation' => 'or',
					'terms'    => array(
						array(
							'name'     => 'style',
							'operator' => '==',
							'value'    => 'style1',
						),
						array(
							'name'     => 'style',
							'operator' => '==',
							'value'    => 'style2',
						),
					),
				),
				
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);
		$this->add_control(
			'bgimg2',
			[
				'label' => esc_html__('Background image', 'rashid'),
					'conditions' => array(
					'relation' => 'and',
					'terms'    => array(
						array(
							'name'     => 'style',
							'operator' => '==',
							'value'    => 'style3',
						),
					
					),
				),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);
		
	$this->add_control(
			'sec_class',
			[
				'label'       => __( 'Section Class', 'rashid' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter Section Class', 'rashid' ),
			]
		);

		$this->end_controls_section();
		
		
		// New Tab#1

		$this->start_controls_section(
					'content_section',
					[
						'label' => __( 'Slider List', 'rashid' ),
						'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
					]
				);
		
				$this->add_control(
				  'repeat', 
					[
						'type' => Controls_Manager::REPEATER,
						'seperator' => 'before',
						'default' => 
							[
								['block_title' => esc_html__('Projects Completed', 'rashid')],
							],
						'fields' => 
							[
								'block_bgimg' => 
								[
									'name' => 'block_bgimg',
									'label' => esc_html__('Background image', 'rashid'),
									'type' => Controls_Manager::MEDIA,
									'default' => ['url' => Utils::get_placeholder_image_src(),],
								],
								'block_image' => 
								[
									'name' => 'block_image',
									'label' => __( 'Image', 'rashid' ),
									'type' => Controls_Manager::MEDIA,
									'default' => ['url' => Utils::get_placeholder_image_src(),],
								],
								'block_alt_text' => 
								[
									'name' => 'block_alt_text',
									'label' => esc_html__('Alt Text', 'rashid'),
									'type' => Controls_Manager::TEXTAREA,
									'default' => esc_html__('', 'rashid')
								],
								'block_title' => 
								[
									'name' => 'block_title',
									'label' => esc_html__('Title', 'rashid'),
									'type' => Controls_Manager::TEXTAREA,
									'default' => esc_html__('', 'rashid')
								],
								'block_text' => 
								[
									'name' => 'block_text',
									'label' => esc_html__('Text', 'rashid'),
									'type' => Controls_Manager::TEXTAREA,
									'default' => esc_html__('', 'rashid')
								],
								'block_button' => 
								[
									'name' => 'block_button',
									'label'       => __( 'Button', 'rashid' ),
									'type'        => Controls_Manager::TEXT,
									'dynamic'     => [
										'active' => true,
									],
									'placeholder' => __( 'Enter your Button Title', 'rashid' ),
								],
								'block_btnlink' => 
								[
									'name' => 'block_btnlink',
									'label' => __( 'Button Url', 'rashid' ),
									'type' => Controls_Manager::URL,
									'placeholder' => __( 'https://your-link.com', 'rashid' ),
									'show_external' => true,
									'default' => [
									'url' => '',
									'is_external' => true,
									'nofollow' => true,
									],
								],
							],
						'title_field' => '{{block_title}}',
					 ]
			);
				
				
		$this->end_controls_section();
		
		// Title 	==================			
		$this->start_controls_section(
			'title_settings',
			array(
				'label' => __( 'Title Setting', 'ecolab' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);
				
		$this->add_control(
			'show_title',
			array(
				'label' => esc_html__( 'Show Title', 'ecolabe' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'show' => [
						'show' => esc_html__( 'Show', 'ecolab' ),	
						'icon' => 'eicon-check-circle',
					],
					'none' => [
						'none' => esc_html__( 'Hide', 'ecolab' ),
						'icon' => 'eicon-close-circle',
					],
				],
				'default' => 'show',
				'selectors' => array(
					'{{WRAPPER}} .banner-carousel .content-box h1' => 'display: {{VALUE}} !important',
				),
			)
		);
		
		$this->add_control(
			'title_alingment',
			array(
				'label' => esc_html__( 'Alignment', 'ecolab' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'ecolab' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'ecolab' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'ecolab' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'center',
				'condition'    => array( 'show_title' => 'show' ),
				'toggle' => true,
				'selectors' => array(
				
					'{{WRAPPER}} .banner-carousel .content-box h1' => 'text-align: {{VALUE}} !important',
				),
			)
		);
		
		$this->add_control(
			'title_margin',
			array(
				'label'     => __( 'Margin', 'ecolab' ),
				'condition'    => array( 'show_title' => 'show' ),
				'type'      => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' =>  ['px', '%', 'em' ],
			
				'selectors' => array(
					'{{WRAPPER}} .banner-carousel .content-box h1' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
				),
			)
		);

		$this->add_control(
			'title_padding',
			array(
				'label'     => __( 'Padding', 'ecolab' ),
				'condition'    => array( 'show_title' => 'show' ),
				'type'      => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' =>  ['px', '%', 'em' ],
			
				'selectors' => array(
					'{{WRAPPER}} .banner-carousel .content-box h1' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
				),
			)
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'title_typography',
				'condition'    => array( 'show_title' => 'show' ),
				'label'    => __( 'Typography', 'ecolab' ),
				'selector' => '{{WRAPPER}} .banner-carousel .content-box h1',
			)
		);
		
		$this->add_control(
			'title_color',
			array(
				'label'     => __( 'Color', 'ecolab' ),
				'condition'    => array( 'show_title' => 'show' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .banner-carousel .content-box h1' => 'color: {{VALUE}} !important',
		
				),
			)
		);

		$this->end_controls_section();					
		//End of  Title 	==================

		//Text==========================
		$this->start_controls_section(
			'text_settings',
			array(
				'label' => __( 'Text Setting', 'ecolab' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);
		
		$this->add_control(
			'show_text',
			array(
				'label' => esc_html__( 'Show Text', 'ecolab' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'show' => [
						'show' => esc_html__( 'Show', 'ecolab' ),	
						'icon' => 'eicon-check-circle',
					],
					'none' => [
						'none' => esc_html__( 'Hide', 'ecolab' ),
						'icon' => 'eicon-close-circle',
					],
				],
				'default' => 'show',
				'selectors' => array(
					'{{WRAPPER}} .banner-carousel .content-box p' => 'display: {{VALUE}} !important',
				),
			)
		);
		
		$this->add_control(
			'text_alingment',
			array(
				'label' => esc_html__( 'Alignment', 'ecolab' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'ecolab' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'ecolab' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'ecolab' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'center',
				'condition'    => array( 'show_text' => 'show' ),
				'toggle' => true,
				'selectors' => array(
					'{{WRAPPER}} .banner-carousel .content-box p' => 'text-align: {{VALUE}} !important',
				),
			)
		);
		
		$this->add_control(
			'text_margin',
			array(
				'label'     => __( 'Margin', 'ecolab' ),
				'type'      => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' =>  ['px', '%', 'em' ],
				'condition'    => array( 'show_text' => 'show' ),
				'selectors' => array(
					'{{WRAPPER}} .banner-carousel .content-box p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
				),
			)
		);
		
		$this->add_control(
			'text_padding',
			array(
				'label'     => __( 'Padding', 'ecolab' ),
				'type'      => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' =>  ['px', '%', 'em' ],
				'condition'    => array( 'show_text' => 'show' ),
				'selectors' => array(
					'{{WRAPPER}} .banner-carousel .content-box p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
				),
			)
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'text_typography',
				'condition'    => array( 'show_text' => 'show' ),
				'label'    => __( 'Typography', 'ecolab' ),
				'selector' => '{{WRAPPER}} .banner-carousel .content-box p',
			)
		);
		
		$this->add_control(
			'text_color',
			array(
				'label'     => __( 'Color', 'ecolab' ),
				'condition'    => array( 'show_text' => 'show' ),
				'separator' => 'after',
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .banner-carousel .content-box p' => 'color: {{VALUE}} !important',
				),
			)
		);

		$this->end_controls_section();
		//End of Text=========	
		
		//========== Button with Background =======================
		$this->start_controls_section(
			'button_control',
			array(
				'label' => __( 'Button Settings', 'ecolab' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);
		
		$this->add_control(
			'show_button',
			array(
				'label' => esc_html__( 'Show Button', 'ecolab' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'show' => [
						'show' => esc_html__( 'Show', 'ecolab' ),	
						'icon' => 'eicon-check-circle',
					],
					'none' => [
						'none' => esc_html__( 'Hide', 'ecolab' ),
						'icon' => 'eicon-close-circle',
					],
				],
				'default' => 'show',
				'selectors' => array(
					'{{WRAPPER}} .banner-carousel .content-box .btn-box' => 'display: {{VALUE}} !important',
				),
			)
		);	
		
		$this->add_control(
			'button_alingment',
			array(
				'label' => esc_html__( 'Alignment', 'ecolab' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'condition'    => array( 'show_button' => 'show' ),
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'ecolab' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'ecolab' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'ecolab' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
				'selectors' => array(
					'{{WRAPPER}} .banner-carousel .content-box .btn-box' => 'text-align: {{VALUE}} !important',
				),
			)
		);	
		
		$this->add_control(
			'button_color',
			array(
				'label'     => __( 'Button Color', 'ecolab' ),
				'condition'    => array( 'show_button' => 'show' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .banner-carousel .content-box .btn-box .theme-btn' => 'color: {{VALUE}} !important',
				),
			)
		);
		
		$this->add_control(
			'button_bg_color',
			array(
				'label'     => __( 'Background Color', 'ecolab' ),
				'condition'    => array( 'show_button' => 'show' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .banner-carousel .content-box .btn-box .theme-btn' => 'background: {{VALUE}} !important',
				),
			)
		);
		
		$this->add_control(
			'button_hover_color',
			array(
				'label'     => __( 'Button Hover Color', 'ecolab' ),
				'condition'    => array( 'show_button' => 'show' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .banner-carousel .content-box .btn-box .theme-btn:hover' => 'color: {{VALUE}} !important',
				),
			)
		);
		
		$this->add_control(
			'button_hover_bgcolor',
			array(
				'label'     => __( 'Hover Bg Color', 'ecolab' ),
				'condition'    => array( 'show_button' => 'show' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .banner-carousel .content-box .btn-box .theme-btn:before' => 'background: {{VALUE}} !important',
				),
			)
		);	
		
		$this->add_control(
			'button_padding',
			array(
				'label'     => __( 'Padding', 'ecolab' ),
				'type'      => \Elementor\Controls_Manager::DIMENSIONS,
				'condition'    => array( 'show_button' => 'show' ),
				'size_units' =>  ['px', '%', 'em' ],
			
				'selectors' => array(
					'{{WRAPPER}} .banner-carousel .content-box .btn-box .theme-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
				),
			)
		);

		$this->add_control(
			'button_margin',
			array(
				'label'     => __( 'Margin', 'ecolab' ),
				'type'      => \Elementor\Controls_Manager::DIMENSIONS,
				'condition'    => array( 'show_button' => 'show' ),
				'size_units' =>  ['px', '%', 'em' ],
				'selectors' => array(
					'{{WRAPPER}} .banner-carousel .content-box .btn-box .theme-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'button_typography',
				'condition'    => array( 'show_button' => 'show' ),
				'label'    => __( 'Typography', 'ecolab' ),
				'selector' => '{{WRAPPER}} .banner-carousel .content-box .btn-box .theme-btn',
			)
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			array(
				'name' => 'border',
				'condition'    => array( 'show_button' => 'show' ),
				'selector' => '{{WRAPPER}} .banner-carousel .content-box .btn-box .theme-btn',
			)
		);
		
		$this->add_control(
			'border_radius',
			array(
				'label'     => __( 'Border Radius', 'ecolab' ),
				'type'      => \Elementor\Controls_Manager::DIMENSIONS,
				'condition'    => array( 'show_button' => 'show' ),
				'size_units' =>  ['px', '%', 'em' ],
			
				'selectors' => array(
					'{{WRAPPER}} .banner-carousel .content-box .btn-box .theme-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
					'{{WRAPPER}} .banner-carousel .content-box .btn-box .theme-btn:before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
				),
			)
		);
		
		$this->end_controls_section();
		
		//End of Button			
		
		//========== Nav Button with Background ===================================

		$this->start_controls_section(
			'nav_button_control',
			array(
				'label' => __( 'Nav Button Settings', 'ecolab' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);
		
		$this->add_control(
			'show_nav_button',
			array(
				'label' => esc_html__( 'Show Nav Button', 'ecolab' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'show' => [
						'show' => esc_html__( 'Show', 'ecolab' ),	
						'icon' => 'eicon-check-circle',
					],
					'none' => [
						'none' => esc_html__( 'Hide', 'ecolab' ),
						'icon' => 'eicon-close-circle',
					],
				],
				'default' => 'show',
				'selectors' => array(
					'{{WRAPPER}} .banner-carousel .owl-nav' => 'display: {{VALUE}} !important',
				),
			)
		);		
		
		$this->add_control(
			'nav_button_color',
			array(
				'label'     => __( 'Nav Button Color', 'ecolab' ),
				'condition'    => array( 'show_nav_button' => 'show' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .banner-carousel .owl-nav button' => 'color: {{VALUE}} !important',

				),
			)
		);
		$this->add_control(
			'nav_button_bg_color',
			array(
				'label'     => __( 'Nav Background Color', 'ecolab' ),
				'condition'    => array( 'show_nav_button' => 'show' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .banner-carousel .owl-nav button' => 'background: {{VALUE}} !important',
				),
			)
		);	
		$this->add_control(
			'nav_button_hover_color',
			array(
				'label'     => __( 'Hover Nav Color', 'ecolab' ),
				'condition'    => array( 'show_nav_button' => 'show' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .banner-carousel .owl-nav button:hover' => 'color: {{VALUE}} !important',
				),
			)
		);
		
		$this->add_control(
			'nav_button_hover_bg_color',
			array(
				'label'     => __( 'Hover Nav Bg Color', 'ecolab' ),
				'condition'    => array( 'show_nav_button' => 'show' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .banner-carousel .owl-nav button:hover' => 'background: {{VALUE}} !important',
				),
			)
		);
		$this->add_control(
			'nav_button_padding',
			array(
				'label'     => __( 'Nav Padding', 'ecolab' ),
				'type'      => \Elementor\Controls_Manager::DIMENSIONS,
				'condition'    => array( 'show_nav_button' => 'show' ),
				'size_units' =>  ['px', '%', 'em' ],
			
				'selectors' => array(
					'{{WRAPPER}} .banner-carousel .owl-nav button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
				),
			)
		);

		$this->add_control(
			'nav_button_margin',
			array(
				'label'     => __( 'Nav Margin', 'ecolab' ),
				'type'      => \Elementor\Controls_Manager::DIMENSIONS,
				'condition'    => array( 'show_nav_button' => 'show' ),
				'size_units' =>  ['px', '%', 'em' ],
				'selectors' => array(
					'{{WRAPPER}} .banner-carousel .owl-nav button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'nav_button_typography',
				'condition'    => array( 'show_nav_button' => 'show' ),
				'label'    => __( 'Typography', 'ecolab' ),
				'selector' => '{{WRAPPER}} .banner-carousel .owl-nav button',
			)
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			array(
				'name' => 'nav_border',
				'condition'    => array( 'show_nav_button' => 'show' ),
				'selector' => '{{WRAPPER}} .banner-carousel .owl-nav button',
			)
		);
		$this->add_control(
			'nav_border_radius',
			array(
				'label' => esc_html__( 'Nav Border Radius', 'ecolab' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'condition'    => array( 'show_nav_button' => 'show' ),
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .banner-carousel .owl-nav button' => 'border-radius: {{SIZE}}{{UNIT}};',
				],
			)
		);

		$this->end_controls_section();
		
		//End of Nav Button	
		
	}

	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
		?>
		
<?php
      echo '
     <script>
 jQuery(document).ready(function($) {

//put the js code under this line 

if ($(".banner-carousel").length) {
	$(".banner-carousel").owlCarousel({
		loop:true,
		margin:0,
		nav:true,
		active: true,
		smartSpeed: 1000,
		autoplay: 6000,
		responsive:{
			0:{
				items:1
			},
			600:{
				items:1
			},
			800:{
				items:1
			},
			1024:{
				items:1
			}
		}
	});
}

//put the code above the line 

  });
</script>';


?>
		

		<?php  if ( 'style1' === $settings['style'] ) : ?>

        <section class="banner-section centred p_relative <?php echo esc_attr($settings['sec_class']);?>">
		
			<?php  if ( esc_url($settings['bgimg']['id']) ) : ?>
            <div class="pattern-layer" style="background-image: url(<?php echo wp_get_attachment_url($settings['bgimg']['id']);?>);">
			<?php else :?>	
			<div class="pattern-layer">
			<?php endif;?>
			</div>
			
            <div class="banner-carousel owl-theme owl-carousel owl-dots-none">
			
				<?php foreach($settings['repeat'] as $item):?>
			
                <div class="slide-item p_relative pt_130 pb_190">
				
					
					<?php if(wp_get_attachment_url($item['block_bgimg']['id'])): ?>
                    <div class="image-layer p_absolute" style="background-image:url(<?php echo wp_get_attachment_url($item['block_bgimg']['id']);?>)">
					<?php else :?>
					<div class="image-layer p_absolute">
					<?php endif;?>
					</div>
                    <div class="auto-container">
                        <div class="content-box p_relative d_block z_5">
                            <h1 class="color_white d_block fs_90 lh_90 mb_25"><?php echo wp_kses($item['block_title'], $allowed_tags);?></h1>
                            <p class="color_white fs_20 lh_32 mb_45"><?php echo wp_kses($item['block_text'], $allowed_tags);?></p>
							
							<?php if(wp_kses($item['block_button'], $allowed_tags)): ?>
							
                            <div class="btn-box clearfix">
                                <a href="<?php echo esc_url($item['block_btnlink']['url']);?>" class="theme-btn btn-one"><?php echo wp_kses($item['block_button'], $allowed_tags);?></a>
                            </div>
							
							<?php endif; ?>
							
                        </div> 
                    </div>
                </div>
				
				<?php endforeach; ?>
				
            </div>
        </section>
		
		<?php endif;?>
		
		<?php  if ( 'style2' === $settings['style'] ) : ?>
		
		<section class="banner-section style-two p_relative <?php echo esc_attr($settings['sec_class']);?>">
			<?php  if ( esc_url($settings['bgimg']['id']) ) : ?>
            <div class="pattern-layer" style="background-image: url(<?php echo wp_get_attachment_url($settings['bgimg']['id']);?>);">
			<?php else :?>	
			<div class="pattern-layer">
			<?php endif;?>
			</div>
            <div class="banner-carousel owl-theme owl-carousel owl-dots-none">
			
				<?php foreach($settings['repeat'] as $item):?>
			
                <div class="slide-item p_relative pt_110 pb_240">
                    <?php if(wp_get_attachment_url($item['block_bgimg']['id'])): ?>
                    <div class="image-layer p_absolute" style="background-image:url(<?php echo wp_get_attachment_url($item['block_bgimg']['id']);?>)">
					<?php else :?>
					<div class="image-layer p_absolute">
					<?php endif;?>
					</div>
                    <div class="auto-container">
                        <div class="content-box p_relative d_block z_5 mr-0">
                            <h1 class="color_white d_block fs_80 lh_90 mb_13"><?php echo wp_kses($item['block_title'], $allowed_tags);?></h1>
                            <p class="color_white fs_20 lh_32 mb_35"><?php echo wp_kses($item['block_text'], $allowed_tags);?></p>
							
							
                            <?php if(wp_kses($item['block_button'], $allowed_tags)): ?>
							
                            <div class="btn-box clearfix">
                                <a href="<?php echo esc_url($item['block_btnlink']['url']);?>" class="theme-btn btn-one"><?php echo wp_kses($item['block_button'], $allowed_tags);?></a>
                            </div>
							
							<?php endif; ?>
							
							
                        </div> 
                    </div>
                </div>
				
				<?php endforeach; ?>
				
            </div>
        </section>
		
		<?php endif;?>
		
		<?php  if ( 'style3' === $settings['style'] ) : ?>
		
		
		<section class="banner-section style-three p_relative bg_white  <?php echo esc_attr($settings['sec_class']);?>">
            <div class="shape-layer">
				<?php  if ( esc_url($settings['bgimg']['id']) ) : ?>
                <div class="shape-1 p_absolute" style="background-image: url(<?php echo wp_get_attachment_url($settings['bgimg']['id']);?>);">
				<?php else :?>	
				<div class="noimage">
				<?php endif;?>
				</div>
				<?php  if ( esc_url($settings['bgimg2']['id']) ) : ?>
                <div class="shape-2 p_absolute" style="background-image: url(<?php echo wp_get_attachment_url($settings['bgimg2']['id']);?>);">
				<?php else :?>	
				<div class="noimage">
				<?php endif;?>
				</div>
            </div>
            <div class="banner-carousel owl-theme owl-carousel owl-dots-none">
			
				<?php foreach($settings['repeat'] as $item):?>
			
                <div class="slide-item p_relative pt_340 pb_240">
                    <div class="auto-container">
                        <div class="content-inner p_relative d_block">
                            <div class="content-box p_relative d_block z_5 mr-0">
                                <h1 class="d_block fs_80 lh_90 mb_13"><?php echo wp_kses($item['block_title'], $allowed_tags);?></h1>
                                <p class="fs_20 lh_32 mb_35"><?php echo wp_kses($item['block_text'], $allowed_tags);?></p>
								
								<?php if(wp_kses($item['block_button'], $allowed_tags)): ?>
                                <div class="btn-box clearfix">
                                    <a href="<?php echo esc_url($item['block_btnlink']['url']);?>" class="theme-btn btn-one"><?php echo wp_kses($item['block_button'], $allowed_tags);?></a>
                                </div>
								<?php endif; ?>
								
                            </div>
                            <div class="image-box p_absolute">
                                <div class="image">
								
								<?php if(wp_get_attachment_url($item['block_image']['id'])): ?>
								<img src="<?php echo wp_get_attachment_url($item['block_image']['id']);?>" alt="<?php echo wp_kses($item['block_alt_text'], $allowed_tags);?>">
								<?php else :?>
								<div class="noimage"></div>
								<?php endif;?>
								
								</div>
                                <div class="image-shape">
                                    <div class="shape-1 p_absolute"></div>
									<?php if(wp_get_attachment_url($item['block_bgimg']['id'])): ?>
                                    <div class="shape-2 p_absolute" style="background-image: url(<?php echo wp_get_attachment_url($item['block_bgimg']['id']);?>);">
									<?php else :?>
									<div class="image-layer p_absolute">
									<?php endif;?>
									</div>
                                </div>
                            </div>
                        </div> 
                    </div>
                </div>
				
				<?php endforeach; ?>
				
            </div>
        </section>
		
		<?php endif;?>
            
		<?php 
	}

}
