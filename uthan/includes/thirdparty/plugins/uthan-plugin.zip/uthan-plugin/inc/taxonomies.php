<?php

namespace UTHANPLUGIN\Inc;


use UTHANPLUGIN\Inc\Abstracts\Taxonomy;


class Taxonomies extends Taxonomy {


	public static function init() {

		$labels = array(
			'name'              => _x( 'Project Category', 'wputhan' ),
			'singular_name'     => _x( 'Project Category', 'wputhan' ),
			'search_items'      => __( 'Search Category', 'wputhan' ),
			'all_items'         => __( 'All Categories', 'wputhan' ),
			'parent_item'       => __( 'Parent Category', 'wputhan' ),
			'parent_item_colon' => __( 'Parent Category:', 'wputhan' ),
			'edit_item'         => __( 'Edit Category', 'wputhan' ),
			'update_item'       => __( 'Update Category', 'wputhan' ),
			'add_new_item'      => __( 'Add New Category', 'wputhan' ),
			'new_item_name'     => __( 'New Category Name', 'wputhan' ),
			'menu_name'         => __( 'Project Category', 'wputhan' ),
		);
		$args   = array(
			'hierarchical'       => true,
			'labels'             => $labels,
			'show_ui'            => true,
			'show_admin_column'  => true,
			'query_var'          => true,
			'public'             => true,
			'publicly_queryable' => true,
			'rewrite'            => array( 'slug' => 'project_cat' ),
		);

		register_taxonomy( 'project_cat', 'uthan_project', $args );
		
		//Services Taxonomy Start
		$labels = array(
			'name'              => _x( 'Service Category', 'wputhan' ),
			'singular_name'     => _x( 'Service Category', 'wputhan' ),
			'search_items'      => __( 'Search Category', 'wputhan' ),
			'all_items'         => __( 'All Categories', 'wputhan' ),
			'parent_item'       => __( 'Parent Category', 'wputhan' ),
			'parent_item_colon' => __( 'Parent Category:', 'wputhan' ),
			'edit_item'         => __( 'Edit Category', 'wputhan' ),
			'update_item'       => __( 'Update Category', 'wputhan' ),
			'add_new_item'      => __( 'Add New Category', 'wputhan' ),
			'new_item_name'     => __( 'New Category Name', 'wputhan' ),
			'menu_name'         => __( 'Service Category', 'wputhan' ),
		);
		$args   = array(
			'hierarchical'       => true,
			'labels'             => $labels,
			'show_ui'            => true,
			'show_admin_column'  => true,
			'query_var'          => true,
			'public'             => true,
			'publicly_queryable' => true,
			'rewrite'            => array( 'slug' => 'service_cat' ),
		);


		register_taxonomy( 'service_cat', 'uthan_service', $args );
		
		//Testimonials Taxonomy Start
		$labels = array(
			'name'              => _x( 'Testimonials Category', 'wputhan' ),
			'singular_name'     => _x( 'Testimonials Category', 'wputhan' ),
			'search_items'      => __( 'Search Category', 'wputhan' ),
			'all_items'         => __( 'All Categories', 'wputhan' ),
			'parent_item'       => __( 'Parent Category', 'wputhan' ),
			'parent_item_colon' => __( 'Parent Category:', 'wputhan' ),
			'edit_item'         => __( 'Edit Category', 'wputhan' ),
			'update_item'       => __( 'Update Category', 'wputhan' ),
			'add_new_item'      => __( 'Add New Category', 'wputhan' ),
			'new_item_name'     => __( 'New Category Name', 'wputhan' ),
			'menu_name'         => __( 'Testimonials Category', 'wputhan' ),
		);
		$args   = array(
			'hierarchical'       => true,
			'labels'             => $labels,
			'show_ui'            => true,
			'show_admin_column'  => true,
			'query_var'          => true,
			'public'             => true,
			'publicly_queryable' => true,
			'rewrite'            => array( 'slug' => 'testimonials_cat' ),
		);


		register_taxonomy( 'testimonials_cat', 'uthan_testimonials', $args );
		
		
		//Team Taxonomy Start
		$labels = array(
			'name'              => _x( 'Team Category', 'wputhan' ),
			'singular_name'     => _x( 'Team Category', 'wputhan' ),
			'search_items'      => __( 'Search Category', 'wputhan' ),
			'all_items'         => __( 'All Categories', 'wputhan' ),
			'parent_item'       => __( 'Parent Category', 'wputhan' ),
			'parent_item_colon' => __( 'Parent Category:', 'wputhan' ),
			'edit_item'         => __( 'Edit Category', 'wputhan' ),
			'update_item'       => __( 'Update Category', 'wputhan' ),
			'add_new_item'      => __( 'Add New Category', 'wputhan' ),
			'new_item_name'     => __( 'New Category Name', 'wputhan' ),
			'menu_name'         => __( 'Team Category', 'wputhan' ),
		);
		$args   = array(
			'hierarchical'       => true,
			'labels'             => $labels,
			'show_ui'            => true,
			'show_admin_column'  => true,
			'query_var'          => true,
			'public'             => true,
			'publicly_queryable' => true,
			'rewrite'            => array( 'slug' => 'team_cat' ),
		);


		register_taxonomy( 'team_cat', 'uthan_team', $args );
		
		//Faqs Taxonomy Start
		$labels = array(
			'name'              => _x( 'Faqs Category', 'wputhan' ),
			'singular_name'     => _x( 'Faq Category', 'wputhan' ),
			'search_items'      => __( 'Search Category', 'wputhan' ),
			'all_items'         => __( 'All Categories', 'wputhan' ),
			'parent_item'       => __( 'Parent Category', 'wputhan' ),
			'parent_item_colon' => __( 'Parent Category:', 'wputhan' ),
			'edit_item'         => __( 'Edit Category', 'wputhan' ),
			'update_item'       => __( 'Update Category', 'wputhan' ),
			'add_new_item'      => __( 'Add New Category', 'wputhan' ),
			'new_item_name'     => __( 'New Category Name', 'wputhan' ),
			'menu_name'         => __( 'Faq Category', 'wputhan' ),
		);
		$args   = array(
			'hierarchical'       => true,
			'labels'             => $labels,
			'show_ui'            => true,
			'show_admin_column'  => true,
			'query_var'          => true,
			'public'             => true,
			'publicly_queryable' => true,
			'rewrite'            => array( 'slug' => 'faqs_cat' ),
		);


		register_taxonomy( 'faqs_cat', 'uthan_faqs', $args );
	}
	
}
